-- Desenvolvido por Nathally V. B. Machado
CREATE TABLE operadoras (
    codigo_registro INT PRIMARY KEY,
    nome_fantasia VARCHAR(255),
    cnpj VARCHAR(20),
    modalidade VARCHAR(100),
    uf VARCHAR(2)
);
