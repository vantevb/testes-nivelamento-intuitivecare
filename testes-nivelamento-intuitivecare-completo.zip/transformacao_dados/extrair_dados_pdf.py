# Desenvolvido por Nathally V. B. Machado para o processo seletivo da IntuitiveCare
import pdfplumber
import pandas as pd
from zipfile import ZipFile

tabelas = []
with pdfplumber.open("../web_scraping/pdfs/AnexoI.pdf") as pdf:
    for page in pdf.pages:
        try:
            table = page.extract_table()
            if table:
                df = pd.DataFrame(table[1:], columns=table[0])
                tabelas.append(df)
        except:
            continue

df_final = pd.concat(tabelas, ignore_index=True)

df_final["OD"] = df_final["OD"].replace("S", "Consulta Odontológica")
df_final["AMB"] = df_final["AMB"].replace("S", "Ambulatorial")

df_final.to_csv("Teste_Nathally V B Machado.csv", index=False)

with ZipFile("Teste_Nathally V B Machado.zip", "w") as zipf:
    zipf.write("Teste_Nathally V B Machado.csv")
