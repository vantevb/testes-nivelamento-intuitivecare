# Desenvolvido por Nathally V. B. Machado
from flask import Flask, request, jsonify
import pandas as pd

app = Flask(__name__)
df = pd.read_csv("operadoras.csv")

@app.route("/buscar")
def buscar():
    q = request.args.get("q", "").lower()
    resultados = df[df["nome_fantasia"].str.lower().str.contains(q)].to_dict(orient="records")
    return jsonify(resultados)

if __name__ == "__main__":
    app.run(debug=True)
