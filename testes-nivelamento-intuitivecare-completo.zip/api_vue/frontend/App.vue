<template>
  <div>
    <input v-model="termo" @input="buscar" placeholder="Buscar operadora..." />
    <ul>
      <li v-for="op in operadoras" :key="op.codigo_registro">{{ op.nome_fantasia }}</li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return { termo: "", operadoras: [] }
  },
  methods: {
    async buscar() {
      const res = await fetch(`http://localhost:5000/buscar?q=${this.termo}`)
      this.operadoras = await res.json()
    }
  }
}
</script>
