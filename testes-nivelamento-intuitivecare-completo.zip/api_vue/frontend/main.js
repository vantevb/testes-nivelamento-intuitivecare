// Desenvolvido por Nathally V. B. Machado
import { createApp } from 'vue'
import App from './App.vue'
createApp(App).mount('#app')
